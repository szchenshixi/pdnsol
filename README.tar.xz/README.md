# PDN Solver: A Power Delivery Network IR-Drop Analyzer

A C++ tool for solving resistor networks and analyzing IR-drop distribution in Power Delivery Networks (PDNs).

## Overview

This solver reads SPICE netlists describing resistor networks (typically from power grid benchmarks), performs DC analysis, and computes the voltage (IR-drop) distribution across the network. Results are visualized as heatmaps for both the full network and a coarsened representation.

## Prerequisites

- **CMake** ≥ 3.16
- **GCC** ≥ 10 (or compatible C++17 compiler)

## Dependencies

Third-party libraries are automatically downloaded by CMake during configuration. If you are in a restricted network environment (e.g., Redzone or without GitHub access), pre-packaged dependencies are provided:

1. Extract the archive:
``shell
cd 3rdparty
tar -xvf extract_me_<timestamp>.tar.xz
``

2. Once extracted, you will see a folder structure like the following. Then CMake will detect and use the local libraries.

``shell
pdnsol/3rdparty/
├── extract_me_20251203.tar.xz
├── CLI11
├── Eigen5
├── fmt
├── googletest
├── json
├── plog
└── stb
``

To add new dependencies, edit `cmake/find-3rdparty.cmake` while maintaining the existing format.

## Building the Project

``shell
mkdir build && cd build
cmake .. -DCMAKE_BUILD_TYPE=Release
make -j$(nproc)
``

## Specifying a Compiler

If your default gcc is older than GCC 10, or encounter any compilation issues, explicitly set the compiler:

``shell
mkdir build && cd build
CC=gcc-11 CXX=g++-11 cmake ..
make -j$(nproc)
``

## Running the Solver

The project includes test cases from the [IBM Power Grid Benchmarks](https://web.ece.ucsb.edu/~lip/PGBenchmarks/ibmpgbench.html). While you may download it yourself, an archive is also provided. Extract the data before running:

``shell
cd test
tar -xvf data.tar.xz
``

Then, run the solver on a SPICE netlist:

``shell
./build/pdnsol ./test/data/ibmpg/6/ibmpg6.spice
``

## Output

After execution, the solver generates:

- **Detailed voltage map**: `work_full/`
- **Coarsened heatmap**: `work_coarsen/`

These directories contain visualizations of the IR-drop distribution across the power grid.

## Advanced Tutorial: DEF/Tech-Driven Simulation (2DIC + 3DIC)

For a design without explicit resistance or voltage/current source information, we need to (1) extract resistances from physical geometry and (2) embed voltage/current sources. This is done with a set of input files plus a single “driver” JSON config.

This mode supports:
- **2DIC (single die)**: one DEF + sources + tech
- **3DIC (stacked dies)**: multiple dies, each with its own DEF/sources/tech, plus **inter-die stacking resistances**

### Key input concepts (DEF-driven mode)

For each **die**, the tool needs:

- **DEF** (Design Exchange Format): PDN routing/topology and geometry
- **PLOC** (power location) file: voltage source (bump/pad) locations per net
- **Current definition JSON**: current sink regions (blocks/areas) per net
- **Technology parameters**: metal resistivity/thickness, via/TSV resistances, and supply definitions
- **Placement transform** (3DIC): how this die is placed/rotated in the global stack coordinate system

For the **stack** (3DIC), the tool needs:

- **Stacking definitions**: which die/layer interfaces are bonded together, and the effective resistance across that interface

### Example inputs

A simple example is provided under `test/data/def_related/`, including:

- `aes_cipher_top.def`
- `simulation.json` (the main "driver" config; name is arbitrary)
- `current.json`
- `voltage.ploc`

In 3DIC mode, you will typically have **one set of DEF/current/ploc per die** (paths can differ per die), and a single shared driver config describing the whole stack.

---

## Driver configuration: multi-die schema (works for 2DIC and 3DIC)

The DEF-driven driver JSON uses this top-level structure:

- `dies`: a dictionary of die instances (e.g., `die0`, `die1`, …)
- `stackings`: a list of inter-die connections (empty or omitted for 2DIC)
- `simulation`: global simulation controls (grid resolution, net filtering, etc.)

### Minimal single-die example (2DIC, DEF-driven)

A single die is expressed as “one entry” under `dies` and no `stackings`:

``json
{
  "dies": {
    "die0": {
      "files": {
        "def_path": "./test/data/def_related/aes_cipher_top.def",
        "current_src_path": "./test/data/def_related/current.json",
        "voltage_src_path": "./test/data/def_related/voltage.ploc"
      },
      "placement": {
        "rotation": "None",
        "origin": [0, 0]
      },
      "tech": {
        "power_nets": {
          "VDD": { "voltage_volt": 0.8, "package_resistance_ohm": 0.1 }
        },
        "ground_nets": {
          "VSS": { "voltage_volt": 1e-9, "package_resistance_ohm": 0.1 }
        },
        "metal_layers": {
          "met1": { "resistivity_ohm_x_um": 0.03, "thickness_um": 0.02 },
          "met2": { "resistivity_ohm_x_um": 0.03, "thickness_um": 0.02 }
        },
        "vias": {
          "via12": { "bottom_layer": "met1", "top_layer": "met2", "resistance_ohm": 1e-4 }
        },
        "tsvs": {},
        "bump_layer": "met2"
      }
    }
  },
  "stackings": [],
  "simulation": {
    "grid": {
      "die0": {
        "default": { "sx": 12, "sy": 12 }
      }
    },
    "net_filter": {
      "include_power": true,
      "include_ground": true,
      "include_nets": [],
      "exclude_nets": []
    }
  }
}
``

Notes:
- The file name does *not* have to be `simulation.json`. You can name it `simulation2d.json`, etc.
- `stackings` is an empty list for 2DIC.
- `current_src_path` / `voltage_src_path` can be set to `""` to disable that source type for a die.

---

## Two-die example (3DIC, DEF-driven)

A 3D stack is described by multiple `dies` plus one or more `stackings` entries:

``json
{
  "dies": {
    "die0": {
      "files": {
        "def_path": "./test/data/def_related/aes_cipher_top.def",
        "current_src_path": "./test/data/def_related/current.json",
        "voltage_src_path": "./test/data/def_related/voltage.ploc"
      },
      "placement": { "rotation": "None", "origin": [0, 0] },
      "tech": {
        "power_nets": {
          "VDD": { "voltage_volt": 0.8, "package_resistance_ohm": 0.1 }
        },
        "ground_nets": {
          "VSS": { "voltage_volt": 1e-9, "package_resistance_ohm": 0.1 }
        },
        "metal_layers": {
          "met1": { "resistivity_ohm_x_um": 0.03, "thickness_um": 0.02 },
          "met2": { "resistivity_ohm_x_um": 0.03, "thickness_um": 0.02 },
          "met3": { "resistivity_ohm_x_um": 0.03, "thickness_um": 0.02 },
          "met4": { "resistivity_ohm_x_um": 0.03, "thickness_um": 0.04 },
          "met5": { "resistivity_ohm_x_um": 0.03, "thickness_um": 0.04 }
        },
        "vias": {
          "via_1920x980": { "bottom_layer": "met1", "top_layer": "met2", "resistance_ohm": 1e-4 },
          "via2_1920x980": { "bottom_layer": "met2", "top_layer": "met3", "resistance_ohm": 1e-4 },
          "via3_1920x980": { "bottom_layer": "met3", "top_layer": "met4", "resistance_ohm": 1e-4 },
          "via4_1600x1600": { "bottom_layer": "met4", "top_layer": "met5", "resistance_ohm": 1e-4 }
        },
        "tsvs": {
          "dummy_TSV_power": { "bottom_layer": "met1", "top_layer": "met4", "resistance_ohm": 0.01 },
          "dummy_TSV_ground": { "bottom_layer": "met1", "top_layer": "met4", "resistance_ohm": 0.01 }
        },
        "bump_layer": "met4"
      }
    },

    "die1": {
      "files": {
        "def_path": "./test/data/def_related/aes_cipher_top.def",
        "current_src_path": "",
        "voltage_src_path": ""
      },
      "placement": { "rotation": "None", "origin": [0, 0] },
      "tech": {
        "power_nets": {
          "VDD": { "voltage_volt": 0.8, "package_resistance_ohm": 0.1 }
        },
        "ground_nets": {
          "VSS": { "voltage_volt": 1e-9, "package_resistance_ohm": 0.1 }
        },
        "metal_layers": {
          "met1": { "resistivity_ohm_x_um": 0.03, "thickness_um": 0.02 },
          "met2": { "resistivity_ohm_x_um": 0.03, "thickness_um": 0.02 },
          "met3": { "resistivity_ohm_x_um": 0.03, "thickness_um": 0.02 },
          "met4": { "resistivity_ohm_x_um": 0.03, "thickness_um": 0.04 },
          "met5": { "resistivity_ohm_x_um": 0.03, "thickness_um": 0.04 }
        },
        "vias": {
          "via_1920x980": { "bottom_layer": "met1", "top_layer": "met2", "resistance_ohm": 1e-4 },
          "via2_1920x980": { "bottom_layer": "met2", "top_layer": "met3", "resistance_ohm": 1e-4 },
          "via3_1920x980": { "bottom_layer": "met3", "top_layer": "met4", "resistance_ohm": 1e-4 },
          "via4_1600x1600": { "bottom_layer": "met4", "top_layer": "met5", "resistance_ohm": 1e-4 }
        },
        "tsvs": {
          "dummy_TSV_power": { "bottom_layer": "met1", "top_layer": "met4", "resistance_ohm": 0.01 },
          "dummy_TSV_ground": { "bottom_layer": "met1", "top_layer": "met4", "resistance_ohm": 0.01 }
        },
        "bump_layer": "met4"
      }
    }
  },

  "stackings": [
    {
      "top_die": "die0",
      "top_layer": "met4",
      "bottom_die": "die1",
      "bottom_layer": "met4",
      "resistance_ohm": 10
    }
  ],

  "simulation": {
    "grid": {
      "die0": { "default": { "sx": 12, "sy": 12 } },
      "die1": { "default": { "sx": 12, "sy": 12 } }
    },
    "net_filter": {
      "include_power": true,
      "include_ground": true,
      "include_nets": ["VSS"],
      "exclude_nets": []
    }
  }
}
``

---

## Understanding `simulation3D.json`

`simulation3D.json` is just a conventional name for a driver JSON using the **multi-die schema** above. The same schema can represent:
- **2DIC**: one die under `dies`, with `stackings: []`
- **3DIC**: multiple dies under `dies`, with one or more `stackings` entries

Below is a field-by-field reference for the 3DIC-specific parts and the updated DEF-driven settings.

### 1) `dies`: per-die inputs, placement, and tech

Each entry under `dies` defines one die instance. Dies are referenced by name from other parts of the config (e.g., `stackings`, `simulation.grid`).

#### `dies.<die>.files`

- `def_path` (string, required)  
  Path to the DEF file for this die. Used to extract die size, PDN routing shapes, and net geometry.

- `current_src_path` (string, optional)  
  Path to the current-sink definition JSON for this die.  
  If `""`, no current sinks are added for this die.

- `voltage_src_path` (string, optional)  
  Path to the PLOC file defining bump/pad locations for this die.  
  If `""`, no voltage sources are added for this die.

Practical 3DIC usage:
- A “top” die might have **no package bumps** (`voltage_src_path: ""`) and receives power through stacking/TSVs.
- Another die might host the bumps and act as the main entry point of supply.

#### `dies.<die>.placement`

Placement aligns each die into a global coordinate system so the solver can:
- build per-die grids
- connect dies through `stackings` using XY overlap/alignment

Fields:
- `origin`: `[x, y]`  
  Translation applied to the die’s DEF coordinates to place it in the global stack plane.

- `rotation`: string  
  Rotation applied around the die origin before translation. Use `"None"` for no rotation.  
  (If you use rotations, ensure your PLOC/current regions are defined consistently with the transformed placement.)

#### `dies.<die>.tech`

Defines how geometry becomes resistance and how supplies are modeled.

- `power_nets` / `ground_nets`  
  Dictionaries keyed by net name (e.g., `VDD`, `VSS`). Each net defines:
  - `voltage_volt`: ideal source voltage for that net on this die
  - `package_resistance_ohm`: optional series resistance to model package/board path

- `metal_layers`  
  Per-layer electrical parameters used to compute sheet/segment resistances from extracted geometry.
  - `resistivity_ohm_x_um` and `thickness_um` are used by the tool’s internal resistance model.
    (Conceptually, resistance scales like \(R \propto \rho \, L / (t \, w)\).)

- `vias`  
  Vertical connections between adjacent (or named) layers inside the die.
  Each via entry declares:
  - `bottom_layer`
  - `top_layer`
  - `resistance_ohm` (effective resistance per via instance in the coarse model)

- `tsvs`  
  Coarse vertical interconnect elements spanning multiple layers inside the die (e.g., `met1` to `met4`).
  Each TSV entry declares:
  - `bottom_layer`
  - `top_layer`
  - `resistance_ohm`

- `bump_layer`  
  The metal layer where bump/pad connections are assumed to land for this die (used when embedding voltage sources from PLOC).

### 2) `stackings`: inter-die connections (the 3D part)

`stackings` describes electrical coupling between two dies through bonding interfaces (micro-bumps, hybrid bonds, interposer connections, etc.).

Each stacking entry:

- `top_die`: name of the die above in the stack (must match a key in `dies`)
- `bottom_die`: name of the die below in the stack
- `top_layer`: metal layer on `top_die` where the interface connects (e.g., `met4`)
- `bottom_layer`: metal layer on `bottom_die` where the interface connects
- `resistance_ohm`: effective resistance used to connect the two dies across this interface

How it is used at a high level:
- The solver builds a coarse PDN network for each die.
- For each stacking entry, the solver adds **vertical conductances between the two dies** (across the overlap region in XY), connecting the specified layers.
- The connection is applied **per net** as derived from DEF connectivity (i.e., it does not “short” unrelated nets together; the net name still comes from the PDN shapes/pins being modeled).

Tips:
- If your stack has multiple interfaces (e.g., `die0↔die1`, `die1↔die2`), add multiple entries.
- Use `placement.origin` / `rotation` to correctly align dies; stacking only makes sense when dies are placed into a consistent global plane.

### 3) `simulation.grid`: per-die coarse grid resolution

The coarse solver discretizes each die into tiles. You configure the tile resolution per die:

``json
"simulation": {
  "grid": {
    "die0": { "default": { "sx": 12, "sy": 12 } },
    "die1": { "default": { "sx": 12, "sy": 12 } }
  }
}
``

- `sx`, `sy` are tile stride lengths (in microns) in X and Y.
- Smaller `sx/sy` ⇒ higher resolution (slower, more accurate)
- Larger `sx/sy` ⇒ lower resolution (faster, less accurate)

`default` applies to all nets for that die unless your build supports per-net overrides.

### 4) `simulation.net_filter`: which nets to solve

This section controls which nets are included in the solve:

- `include_power` (bool): include all nets listed in each die’s `tech.power_nets`
- `include_ground` (bool): include all nets listed in each die’s `tech.ground_nets`
- `include_nets` (list of strings): explicit additional net names to include
- `exclude_nets` (list of strings): net names to remove after inclusion

Common use cases:
- Solve only the main supplies: set `include_power=true`, `include_ground=true`, and keep `include_nets=[]`.
- Solve a specific subset: set `include_power=false`, `include_ground=false`, and list nets in `include_nets`.

---

## Notes on upgrading older DEF-driven configs

If you previously used a single-die DEF-driven schema like:

``json
{
  "file": { "def_path": "...", "current_src_path": "...", "voltage_src_path": "..." },
  "tech": { ... },
  "simulation": { ... }
}
``

it is now expressed as:

- `dies.die0.files` replaces `file`
- `dies.die0.tech` replaces `tech`
- `dies.die0.placement` is added (use origin `[0,0]` and rotation `"None"` for 2DIC)
- `stackings` is added as `[]`

This change enables multi-die stacks without changing the solver’s SPICE-based flow.

```